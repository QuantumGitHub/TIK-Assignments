#ifndef SCALLS_H
#define SCALLS_H

#define SCALL_PRINT 1
#define SCALL_END 2
#define SCALL_EXECV 3
#define SCALL_YIELD 4
#define SCALL_MMAP 5
#define SCALL_GETPID 6
#define SCALL_TIMERSTATUS 7

#endif