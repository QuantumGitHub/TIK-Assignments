void buddy_test(void);
void pt_test(void);
